package com.ziptoapk.converter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var webView: WebView
    private lateinit var chooseButton: Button

    companion object {
        private const val PICK_ZIP = 41
        private const val MAX_ENTRIES = 5_000
        private const val MAX_UNCOMPRESSED_BYTES = 100L * 1024L * 1024L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 16)
        }
        val heading = TextView(this).apply {
            text = "ZIP to APK"
            textSize = 28f
            setPadding(0, 0, 0, 8)
        }
        status = TextView(this).apply {
            text = "Selecciona un ZIP con una web estática que incluya index.html."
            textSize = 15f
            setPadding(0, 0, 0, 16)
        }
        chooseButton = Button(this).apply {
            text = "Seleccionar archivo ZIP"
            setOnClickListener { openZipPicker() }
        }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }
        layout.addView(heading)
        layout.addView(status)
        layout.addView(chooseButton)
        layout.addView(webView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(layout)

        try {
            assets.open("site/index.html").use { }
            status.text = "Sitio web incluido en esta APK."
            webView.loadUrl("file:///android_asset/site/index.html")
        } catch (_: Exception) {
            // Sin sitio incluido, se puede cargar un ZIP desde el selector.
        }
    }

    private fun openZipPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }
        startActivityForResult(intent, PICK_ZIP)
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_ZIP || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        chooseButton.isEnabled = false
        status.text = "Abriendo archivo…"
        try {
            val siteDir = File(cacheDir, "preview-site")
            siteDir.deleteRecursively()
            siteDir.mkdirs()
            unzipSafely(uri, siteDir)
            val index = siteDir.walkTopDown()
                .filter { it.isFile && it.name.equals("index.html", ignoreCase = true) }
                .sortedWith(compareBy<File>({ it.relativeTo(siteDir).toPath().nameCount }, { it.path }))
                .firstOrNull()
                ?: throw IllegalArgumentException("No se encontró index.html en el ZIP.")
            status.text = "Proyecto cargado. Vista previa: ${index.relativeTo(siteDir).path}"
            webView.loadUrl(Uri.fromFile(index).toString())
        } catch (e: Exception) {
            status.text = "No se pudo abrir el ZIP: ${e.message ?: "error desconocido"}"
            Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
        } finally {
            chooseButton.isEnabled = true
        }
    }

    private fun unzipSafely(uri: Uri, destination: File) {
        val base = destination.canonicalFile
        var entryCount = 0
        var totalBytes = 0L
        val input = contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("No se pudo leer el archivo seleccionado.")
        input.use { source ->
            ZipInputStream(source).use { zip ->
                var entry = zip.nextEntry
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (entry != null) {
                    entryCount++
                    require(entryCount <= MAX_ENTRIES) { "El ZIP contiene demasiados archivos." }
                    val output = File(base, entry.name).canonicalFile
                    require(output.path != base.path && output.path.startsWith(base.path + File.separator)) {
                        "El ZIP contiene una ruta no permitida."
                    }
                    if (entry.isDirectory) {
                        output.mkdirs()
                    } else {
                        output.parentFile?.mkdirs()
                        output.outputStream().buffered().use { target ->
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                totalBytes += count
                                require(totalBytes <= MAX_UNCOMPRESSED_BYTES) {
                                    "El contenido descomprimido supera el límite de 100 MB."
                                }
                                target.write(buffer, 0, count)
                            }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        require(entryCount > 0) { "El archivo ZIP está vacío o no es válido." }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
