# ZIP to APK

Aplicación Android para abrir un ZIP de sitio web estático y previsualizar su `index.html`. También puede mostrar inmediatamente un sitio incluido dentro de la APK en `app/src/main/assets/site/`.

## Funciones

- Selector de archivos Android (Storage Access Framework); no solicita permisos de almacenamiento generales.
- Busca `index.html` en la raíz o en una subcarpeta del ZIP y abre la vista previa con sus CSS, JavaScript e imágenes locales.
- Comprueba rutas al extraer y limita la operación a 5.000 entradas y 100 MB descomprimidos para reducir riesgos de ZIP maliciosos o desmesurados.
- El workflow de GitHub Actions compila una APK de depuración. Si se coloca un `website.zip` con `index.html` en la raíz del repositorio, lo incluye automáticamente en la aplicación. Sin ese archivo, compila la app contenedora para abrir ZIPs desde el teléfono.

## Compilar la APK con GitHub Actions

1. Descomprime el contenido de este proyecto y súbelo a la raíz de un repositorio GitHub.
2. En GitHub abre **Actions**, selecciona **Build ZIP to APK** y pulsa **Run workflow**.
3. Descarga el artefacto **zip-to-apk-debug** al terminar y extrae `app-debug.apk`.
4. Instálala en Android. Si quieres incluir una web para que aparezca al abrir, coloca `website.zip` en la raíz del repositorio antes de ejecutar el workflow. El ZIP debe contener `index.html` (en su raíz o dentro de una carpeta).

## Abrir en Android Studio

Abre la carpeta del proyecto (`zip-to-apk`) en Android Studio y deja que Gradle sincronice. Ejecuta la configuración `app` en un dispositivo/emulador Android 6.0 o posterior.

## Límites

Esta app previsualiza sitios web estáticos HTML/CSS/JavaScript. No transforma por sí sola un backend PHP/Node, una base de datos ni un proyecto completo de servidor en una app autónoma. Los sitios que usan servicios externos requieren Internet. La APK generada es de depuración; una publicación formal necesita configuración de firma release.
